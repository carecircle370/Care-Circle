import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;

public class Server {

    private static final int LOGIN_PORT = 1234;        
    private static final int CHAT_PORT = 1235;       
    private static final File CSV_FILE = new File("vitals.csv");
    private static final String QUIT = "QUIT";

    // chat groups: groupName -> list of connected clients
    private static final Map<String, List<ClientHandler>> chatGroups = new ConcurrentHashMap<>();

    public static void main(String[] args) throws IOException {
        System.out.println("Starting server...");

        ensureCsvHeader();

        ExecutorService pool = Executors.newCachedThreadPool();

        ServerSocket csvSocket = new ServerSocket(LOGIN_PORT);
        pool.submit(() -> {
            System.out.println("CSV Server listening on port " + LOGIN_PORT);
            while (true) {
                try {
                    Socket client = csvSocket.accept();
                    pool.submit(() -> handleCsvClient(client));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        ServerSocket chatSocket = new ServerSocket(CHAT_PORT);
        pool.submit(() -> {
            System.out.println("Chat Server listening on port " + CHAT_PORT);
            while (true) {
                try {
                    Socket client = chatSocket.accept();
                    ClientHandler handler = new ClientHandler(client, chatGroups);
                    pool.submit(handler);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        System.out.println("Server running. CSV: " + LOGIN_PORT + ", Chat: " + CHAT_PORT);
    }

    private static void handleCsvClient(Socket socket) {
        String remote = socket.getRemoteSocketAddress().toString();
        System.out.println("Connected (CSV): " + remote);

        try (BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()))) {

            String line;
            while ((line = br.readLine()) != null) {
                String trimmed = line.trim();

                if (QUIT.equalsIgnoreCase(trimmed)) {
                    bw.write("Goodbye");
                    bw.newLine();
                    bw.flush();
                    break;
                }

                if ("LIST ALL".equalsIgnoreCase(trimmed)) {
                    sendCsv(bw, null);
                    continue;
                }

                if (trimmed.toUpperCase().startsWith("LIST ")) {
                    String patientId = trimmed.substring(5).trim();
                    if (patientId.isEmpty()) {
                        bw.write("ERROR: Missing patientId after LIST");
                        bw.newLine();
                        bw.flush();
                    } else {
                        sendCsv(bw, patientId);
                    }
                    continue;
                }

                if (trimmed.isEmpty()) {
                    bw.write("ERROR: empty submission");
                    bw.newLine();
                    bw.flush();
                    continue;
                }

                String submittedAt = Instant.now().toString();
                appendCsvLine(line + "," + submittedAt);

                bw.write("OK saved to vitals.csv");
                bw.newLine();
                bw.flush();
            }
        } catch (IOException e) {
            System.out.println("I/O error (CSV) with " + remote + ": " + e.getMessage());
        } finally {
            try { socket.close(); } catch (IOException ignored) {}
            System.out.println("Disconnected (CSV): " + remote);
        }
    }

    private static void sendCsv(BufferedWriter bw, String filterPatientId) throws IOException {
        ensureCsvHeader();
        try (BufferedReader csv = new BufferedReader(new FileReader(CSV_FILE))) {
            String header = csv.readLine();
            if (header != null) {
                bw.write(header);
                bw.newLine();
            }
            String row;
            while ((row = csv.readLine()) != null) {
                if (filterPatientId == null) {
                    bw.write(row);
                    bw.newLine();
                } else {
                    int comma = row.indexOf(',');
                    String pid = (comma == -1) ? row : row.substring(0, comma);
                    if (filterPatientId.equalsIgnoreCase(pid.trim())) {
                        bw.write(row);
                        bw.newLine();
                    }
                }
            }
        }
        bw.write("END");
        bw.newLine();
        bw.flush();
    }

    private static synchronized void appendCsvLine(String csvLine) {
        try (BufferedWriter csv = new BufferedWriter(new FileWriter(CSV_FILE, true))) {
            csv.write(csvLine);
            csv.newLine();
        } catch (IOException e) {
            throw new RuntimeException("Failed to write CSV: " + e.getMessage(), e);
        }
    }

    private static void ensureCsvHeader() {
        try {
            boolean newFile = CSV_FILE.createNewFile();
            if (newFile || CSV_FILE.length() == 0L) {
                try (BufferedWriter csv = new BufferedWriter(new FileWriter(CSV_FILE, true))) {
                    csv.write("patientId,heartRateBpm,bpSystolic,bpDiastolic,temperatureC,mood,dietNotes,weightKg,submittedAt");
                    csv.newLine();
                }
            }
        } catch (IOException e) {
            throw new RuntimeException("Failed to init CSV: " + e.getMessage(), e);
        }
    }

    private static class ClientHandler implements Runnable {

        private final Socket socket;
        private final BufferedReader br;
        private final BufferedWriter bw;
        private final Map<String, List<ClientHandler>> chatGroups;

        private String username;
        private String groupName;

        public ClientHandler(Socket socket, Map<String, List<ClientHandler>> chatGroups) throws IOException {
            this.socket = socket;
            this.chatGroups = chatGroups;

            this.br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            this.bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));

            // Expect first line: "JOIN|groupName|username"
            String joinLine = br.readLine();
            if (joinLine == null || !joinLine.startsWith("JOIN|")) {
                sendMessage("SERVER: Invalid join message. Disconnecting.");
                closeEverything();
                throw new IOException("Invalid join message from client.");
            }

            String[] parts = joinLine.split("\\|", 3);
            if (parts.length < 3) {
                sendMessage("SERVER: Invalid join format. Disconnecting.");
                closeEverything();
                throw new IOException("Invalid join message from client.");
            }

            this.groupName = parts[1];
            this.username = parts[2];

            chatGroups.computeIfAbsent(groupName, k -> Collections.synchronizedList(new ArrayList<>()))
                    .add(this);

            broadcastToGroup(username + " has joined the group.");

            System.out.println(username + " joined group " + groupName);
        }

        @Override
        public void run() {
            try {
                String msg;
                while ((msg = br.readLine()) != null) {
                    broadcastToGroup(username + ": " + msg);
                }
            } catch (IOException e) {
                System.out.println(username + " disconnected from group " + groupName);
            } finally {
                removeFromGroup();
                closeEverything();
            }
        }

        private void broadcastToGroup(String message) {
            List<ClientHandler> clients = chatGroups.get(groupName);
            if (clients == null) return;

            synchronized (clients) {
                for (ClientHandler client : clients) {
                    client.sendMessage(message);
                }
            }
        }

        private void removeFromGroup() {
            List<ClientHandler> clients = chatGroups.get(groupName);
            if (clients != null) {
                clients.remove(this);
                broadcastToGroup(username + " has left the group.");
            }
        }

        private void sendMessage(String message) {
            try {
                bw.write(message);
                bw.newLine();
                bw.flush();
            } catch (IOException e) {
                closeEverything();
            }
        }

        private void closeEverything() {
            try { if (br != null) br.close(); } catch (IOException ignored) {}
            try { if (bw != null) bw.close(); } catch (IOException ignored) {}
            try { if (socket != null) socket.close(); } catch (IOException ignored) {}
        }
    }
}