package com.carecircleserver.calendarSystem;

public final class CalendarAgent {
    public void showAppointments() {}
    public void showReminders() {}
    public void showVitals() {}
}