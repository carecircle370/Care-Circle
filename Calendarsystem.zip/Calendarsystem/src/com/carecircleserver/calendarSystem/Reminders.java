package com.carecircleserver.calendarSystem;

public final class Reminders {
    public void sendReminders() {}
}