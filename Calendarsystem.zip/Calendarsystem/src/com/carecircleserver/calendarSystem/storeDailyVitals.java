package com.carecircleserver.calendarSystem;

public interface storeDailyVitals {
    boolean storeVitals();
}