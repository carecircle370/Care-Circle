package com.carecircleserver.calendarSystem;

public final class DailyVitalsManager {
    public boolean recordDailyVitals() { return true; }
}