import com.carecircle.core.Dispatchers;
import com.carecircle.ui.AppointmentsPanel;
import com.carecircle.ui.VitalsSubmitPanel;
import com.carecircle.ui.VitalsViewerPanel;

import javax.swing.*;
import java.awt.*;

public class PatientHomeUI extends JFrame {

    private final CareCircleUser user;

    public PatientHomeUI(CareCircleUser user) {
        this.user = user;

        setTitle("Care Circle – Patient UI");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(960, 600);
        setLocationRelativeTo(null);

        setLayout(new BorderLayout(10, 10));
        JComponent content = (JComponent) getContentPane();
        content.setBackground(new Color(245, 250, 255));
        content.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        add(buildHeader(), BorderLayout.NORTH);
        add(buildMainArea(), BorderLayout.CENTER);
    }

    // =====================================
    // Header: avatar + profile + big button
    // =====================================
    private JComponent buildHeader() {
        JPanel header = new JPanel(new BorderLayout(10, 0));
        Color bg = new Color(240, 248, 255); // very light blue
        header.setBackground(bg);

        // Avatar for patient
        AvatarPanel avatar = new AvatarPanel(
                new Color(90, 155, 215),
                new Color(230, 230, 230)
        );

        // Text info block
        JPanel info = new JPanel();
        info.setOpaque(false);
        info.setLayout(new BoxLayout(info, BoxLayout.Y_AXIS));

        info.add(new JLabel("Username: " + user.getUsername()));
        info.add(Box.createVerticalStrut(4));

        info.add(new JLabel("Role: Patient"));
        info.add(Box.createVerticalStrut(4));

        info.add(new JLabel("Full Name: " + user.getFullName()));
        info.add(Box.createVerticalStrut(4));

        JButton editProfile = new JButton("Edit Profile");
        info.add(editProfile);

        header.add(avatar, BorderLayout.WEST);
        header.add(info, BorderLayout.CENTER);

        // Big pill-like button on the right
        JButton viewButton = new JButton(
                "<html><center>View / Enter<br/>Vitals / Reminders / Appointments</center></html>"
        );
        viewButton.setFont(viewButton.getFont().deriveFont(Font.BOLD, 12f));
        viewButton.setPreferredSize(new Dimension(260, 60));

        // Now just use the logged-in user's info (no dialog)
        viewButton.addActionListener(e -> openPatientPortal());

        header.add(viewButton, BorderLayout.EAST);

        return header;
    }

    /**
     * Opens a separate window with tabs:
     * - Vitals (Submit)
     * - Vitals (View)
     * - Appointments
     * Uses the logged-in user's username as Patient ID.
     */
    private void openPatientPortal() {
        String pid = user.getUsername();
        if (pid == null || pid.isBlank()) {
            JOptionPane.showMessageDialog(
                    this,
                    "No Patient ID associated with this account."
            );
            return;
        }

        String pname = user.getFullName();
        if (pname == null) {
            pname = "";
        }

        JFrame frame = new JFrame("CareCircle – Patient Portal");
        frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        frame.setSize(980, 720);
        frame.setLocationRelativeTo(this);

        String trimmedPid = pid.trim();
        String trimmedName = pname.trim();

        JTabbedPane tabs = new JTabbedPane();

        tabs.addTab("Vitals (Submit)", new VitalsSubmitPanel(trimmedPid, trimmedName));
        tabs.addTab("Vitals (View)", new VitalsViewerPanel(
                Dispatchers.Factory.vitalsForPatient(trimmedPid),
                trimmedPid,
                trimmedName
        ));
        tabs.addTab("Appointments", new AppointmentsPanel(
                Dispatchers.Factory.calendarForPatient(trimmedPid),
                trimmedPid,
                trimmedName
        ));

        tabs.setTabComponentAt(0, createTabHeader("Vitals (Submit)", "Submit today's vitals."));
        tabs.setTabComponentAt(1, createTabHeader("Vitals (View)", "See your past vitals."));
        tabs.setTabComponentAt(2, createTabHeader("Appointments", "Book or review appointments."));

        tabs.setToolTipTextAt(0, "Send in your current vitals for your care team.");
        tabs.setToolTipTextAt(1, "Review previously submitted vitals and trends.");
        tabs.setToolTipTextAt(2, "Schedule or check upcoming appointments.");

        frame.setContentPane(tabs);
        frame.setVisible(true);
    }

    private static JComponent createTabHeader(String title, String description) {
        JPanel container = new JPanel();
        container.setOpaque(false);
        container.setLayout(new BoxLayout(container, BoxLayout.Y_AXIS));

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(titleLabel.getFont().deriveFont(Font.BOLD));

        JLabel descLabel = new JLabel(description);
        descLabel.setFont(descLabel.getFont().deriveFont(
                Font.PLAIN,
                titleLabel.getFont().getSize2D() - 2
        ));
        descLabel.setForeground(Color.DARK_GRAY);

        container.add(titleLabel);
        container.add(descLabel);

        return container;
    }

    // ==========================
    // Center: appointments + chat
    // ==========================
    private JComponent buildMainArea() {
        JPanel center = new JPanel(new GridLayout(1, 2, 10, 0));
        center.setBackground(new Color(245, 250, 255));
        center.add(buildAppointmentsPanel());
        center.add(buildChatPanel());
        return center;
    }

    // Left side: list of appointments & reminders for the week
    private JComponent buildAppointmentsPanel() {
        DefaultListModel<String> model = new DefaultListModel<>();

        model.addElement("Mon 10:00 – Dr. Smith (Telehealth)");
        model.addElement("Wed 09:00 – Blood test reminder");
        model.addElement("Fri 15:30 – Physical therapy");
        model.addElement("Daily 08:00 – Morning medication");

        JList<String> list = new JList<>(model);
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scroll = new JScrollPane(list);
        scroll.setBorder(BorderFactory.createTitledBorder(
                "List of Appointments and Reminders for the Week"
        ));

        JPanel panel = new JPanel(new BorderLayout());
        panel.add(scroll, BorderLayout.CENTER);
        return panel;
    }

    // Right side: local chat box UI (separate from your network chat client)
    private JComponent buildChatPanel() {
        JTextArea chatArea = new JTextArea();
        chatArea.setEditable(false);

        JTextField input = new JTextField();
        JButton send = new JButton("Send");

        send.addActionListener(e -> {
            String text = input.getText().trim();
            if (!text.isEmpty()) {
                chatArea.append("You: " + text + "\n");
                input.setText("");
            }
        });

        JPanel bottom = new JPanel(new BorderLayout(5, 0));
        bottom.add(input, BorderLayout.CENTER);
        bottom.add(send, BorderLayout.EAST);

        JPanel panel = new JPanel(new BorderLayout(5, 5));
        panel.setBorder(BorderFactory.createTitledBorder("Chat Box"));
        panel.add(new JScrollPane(chatArea), BorderLayout.CENTER);
        panel.add(bottom, BorderLayout.SOUTH);

        return panel;
    }
}
