package com.carecircle.app;

import com.carecircle.core.Dispatchers;
import com.carecircle.ui.VitalsViewerPanel;
import com.carecircle.ui.UpcomingAppointmentsPanel;
import com.carecircle.ui.ProviderPatientsPanel;

import javax.swing.*;
import java.awt.*;

/** Provider portal with provider-scoped access (assignments persisted to CSV). */
public final class ProviderApp {

    private ProviderApp() {
        // utility class, no instances
    }

    /**
     * Open the Provider Portal for a given providerId.
     * Can be called from DoctorHomeUI or anywhere else.
     */
    public static void openForProvider(String providerId, Component parent) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("CareCircle – Provider Portal");
            frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
            frame.setSize(980, 720);

            if (parent != null) {
                frame.setLocationRelativeTo(parent);
            } else {
                frame.setLocationRelativeTo(null);
            }

            frame.setContentPane(createProviderTabs(providerId));
            frame.setVisible(true);
        });
    }

    /** Shared helper to build tabs for a provider. */
    private static JTabbedPane createProviderTabs(String providerId) {
        JTabbedPane tabs = new JTabbedPane();

        tabs.addTab("Manage Patients", new ProviderPatientsPanel(providerId));

        tabs.addTab("Vitals (View)", new VitalsViewerPanel(
                Dispatchers.Factory.vitalsForProvider(providerId),
                "",
                "",
                "Results are limited to patients assigned to you.",
                true
        ));

        tabs.addTab("Upcoming Appointments",
                new UpcomingAppointmentsPanel(
                        Dispatchers.Factory.calendarForProvider(providerId)));

        return tabs;
    }

    /** Standalone entry point (same behavior as before, but reuses the helper). */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("CareCircle – Provider Portal");
            frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
            frame.setSize(980, 720);
            frame.setLocationRelativeTo(null);

            String providerId = JOptionPane.showInputDialog(frame, "Enter Provider ID:");
            if (providerId == null || providerId.isBlank()) {
                JOptionPane.showMessageDialog(frame, "Provider ID required.");
                frame.dispose();
                return;
            }

            frame.setContentPane(createProviderTabs(providerId.trim()));
            frame.setVisible(true);
        });
    }
}
