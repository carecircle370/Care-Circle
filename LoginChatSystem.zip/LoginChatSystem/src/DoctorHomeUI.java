import com.carecircle.app.ProviderApp;

import javax.swing.*;
import java.awt.*;

public class DoctorHomeUI extends JFrame {

    private final CareCircleUser user;

    public DoctorHomeUI(CareCircleUser user) {
        this.user = user;

        setTitle("Care Circle – Doctor UI");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(960, 600);
        setLocationRelativeTo(null);

        setLayout(new BorderLayout(10, 10));
        JComponent content = (JComponent) getContentPane();
        content.setBackground(new Color(245, 250, 255));
        content.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        add(buildHeader(), BorderLayout.NORTH);
        add(buildMainArea(), BorderLayout.CENTER);
    }

    // =====================================
    // Header: profile + big view-patients button
    // =====================================
    private JComponent buildHeader() {
        JPanel header = new JPanel(new BorderLayout(10, 0));
        Color bg = new Color(232, 248, 244); // soft green
        header.setBackground(bg);

        // Avatar with teal ring for doctor
        AvatarPanel avatar = new AvatarPanel(
                new Color(37, 150, 190),
                new Color(230, 230, 230)
        );

        JPanel info = new JPanel();
        info.setOpaque(false);
        info.setLayout(new BoxLayout(info, BoxLayout.Y_AXIS));

        info.add(new JLabel("Username: " + user.getUsername()));
        info.add(Box.createVerticalStrut(4));

        info.add(new JLabel("Doctor Full Name: " + user.getFullName()));
        info.add(Box.createVerticalStrut(4));

        info.add(new JLabel("Doctor Title: " + user.getTitle()));
        info.add(Box.createVerticalStrut(4));

        JButton editProfile = new JButton("Edit Profile");
        info.add(editProfile);

        header.add(avatar, BorderLayout.WEST);
        header.add(info, BorderLayout.CENTER);

        JButton viewPatientsButton = new JButton(
                "<html><center>View Patients<br/>Vitals / Reminders / Appointments</center></html>"
        );
        viewPatientsButton.setFont(viewPatientsButton.getFont().deriveFont(Font.BOLD, 12f));
        viewPatientsButton.setPreferredSize(new Dimension(280, 60));

        // Use the logged-in doctor's username as Provider ID (no dialog)
        viewPatientsButton.addActionListener(e -> {
            String providerId = user.getUsername();
            if (providerId == null || providerId.isBlank()) {
                JOptionPane.showMessageDialog(
                        this,
                        "No Provider ID associated with this account."
                );
                return;
            }

            ProviderApp.openForProvider(providerId.trim(), this);
        });

        header.add(viewPatientsButton, BorderLayout.EAST);

        return header;
    }

    // ==========================
    // Center area: patients + chat
    // ==========================
    private JComponent buildMainArea() {
        JPanel main = new JPanel(new GridLayout(1, 2, 10, 0));
        main.setBackground(new Color(245, 250, 255));
        main.add(buildPatientsPanel());
        main.add(buildChatPanel());
        return main;
    }

    // Left: list of patients, urgent ones highlighted
    private JComponent buildPatientsPanel() {
        DefaultListModel<String> model = new DefaultListModel<>();

        model.addElement("URGENT – Mark Smith");
        model.addElement("John Doe – Follow-up consultation");
        model.addElement("Maria Lopez – Medication review");

        JList<String> list = new JList<>(model);
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // Red highlight for urgent cases
        list.setCellRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(
                    JList<?> jList, Object value, int index,
                    boolean isSelected, boolean cellHasFocus) {

                JLabel label = (JLabel) super.getListCellRendererComponent(
                        jList, value, index, isSelected, cellHasFocus);

                String text = value.toString();
                if (text.startsWith("URGENT")) {
                    label.setForeground(Color.RED);
                    label.setFont(label.getFont().deriveFont(Font.BOLD));
                } else {
                    label.setForeground(isSelected ? jList.getSelectionForeground()
                            : jList.getForeground());
                    label.setFont(label.getFont().deriveFont(Font.PLAIN));
                }
                return label;
            }
        });

        JScrollPane scroll = new JScrollPane(list);
        scroll.setBorder(BorderFactory.createTitledBorder("List of Patients"));

        JButton btnViewPatient = new JButton("View Selected Patient");
        btnViewPatient.addActionListener(e -> {
            String selected = list.getSelectedValue();
            if (selected == null) {
                JOptionPane.showMessageDialog(this, "Please select a patient.");
            } else {
                JOptionPane.showMessageDialog(
                        this,
                        "Doctor can view patient details for:\n" + selected +
                                "\n(You can later hook this to a patient detail UI.)"
                );
            }
        });

        JPanel bottom = new JPanel();
        bottom.setLayout(new BoxLayout(bottom, BoxLayout.Y_AXIS));
        bottom.add(Box.createVerticalStrut(4));
        bottom.add(btnViewPatient);

        JPanel panel = new JPanel(new BorderLayout(5, 5));
        panel.add(scroll, BorderLayout.CENTER);
        panel.add(bottom, BorderLayout.SOUTH);

        return panel;
    }

    // Right: chat box that launches the shared Chat window
    private JComponent buildChatPanel() {
        JPanel panel = new JPanel(new BorderLayout(5, 5));
        panel.setBorder(BorderFactory.createTitledBorder("Chat Box"));

        JTextArea info = new JTextArea(
                "Chat Box\n\n" +
                        "Use the button below to open the real-time chat window with patients,\n" +
                        "caregivers, or other providers."
        );
        info.setWrapStyleWord(true);
        info.setLineWrap(true);
        info.setEditable(false);

        JButton btnOpenChat = new JButton("Open Chat Window");
        btnOpenChat.addActionListener(e -> {
            // Same Chat client class you use in PatientHomeUI
            new Chat(user.getUsername(), "localhost", 1000);
        });

        panel.add(new JScrollPane(info), BorderLayout.CENTER);
        panel.add(btnOpenChat, BorderLayout.SOUTH);

        return panel;
    }
}
